EMD ver. 1.0, 23/04/2008

Just expand in a folder and read the help of functions
emd.m and emdoptimset.m

Bug reports
at kopsinis@ieee.org.

Yannis Kopsinis
 